import path from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { tanstackRouter } from "@tanstack/router-plugin/vite";

// Static SPA build for GitHub Pages (https://<user>.github.io/<repo>/).
// In GitHub Actions the repo name is read automatically, so renaming the repo is safe.
const repo = process.env["GITHUB_REPOSITORY"]?.split("/")[1];

export default defineConfig({
  base: repo ? `/${repo}/` : "/",
  plugins: [tanstackRouter({ target: "react" }), react(), tailwindcss()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
});
