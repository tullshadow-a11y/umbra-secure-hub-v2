# Umbra Mail

Instant disposable email with a live inbox: one-click random address, copy button, refresh / delete / new address, and clean empty states. Dark glassmorphism UI built with Tailwind CSS.

Inboxes come from the public Guerrilla Mail API, called directly from the browser.

## Stack

React 19, Vite, TanStack Router (file-based routes, hash history), TanStack Query, Tailwind CSS 4, shadcn/ui.

## Development

```sh
npm install
npm run dev      # local dev server
npm test         # unit tests
npm run build    # static build into dist/
```

## Deployment (GitHub Pages)

Live at https://tullshadow-a11y.github.io/umbra-secure-hub/

- `vite.config.ts` derives `base` from the repository name during the GitHub Actions build (and uses `/` locally).
- Routing uses hash history (`/#/path`), so no server-side fallback is needed.
- `.github/workflows/main.yml` builds the app and publishes the `dist/` folder.
- In the repository settings, Pages → Source must be **GitHub Actions**.
